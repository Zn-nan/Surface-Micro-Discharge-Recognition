"""
Visualization utilities for training curves, confusion matrices, and prediction results.
"""
