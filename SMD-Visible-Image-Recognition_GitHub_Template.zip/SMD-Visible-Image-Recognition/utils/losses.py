"""
Loss functions.
"""
