"""
Evaluation metrics, including accuracy, precision, recall, and confusion matrix.
"""
