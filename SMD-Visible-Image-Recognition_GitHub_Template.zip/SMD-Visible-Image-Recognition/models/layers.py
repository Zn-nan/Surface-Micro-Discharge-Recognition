"""
Custom layers or model blocks used by ShuffleNetV2.
"""
