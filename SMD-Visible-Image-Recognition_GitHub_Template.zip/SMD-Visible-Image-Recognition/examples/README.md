# Examples

Place demo images and prediction results in this folder.

Suggested files:

- demo.jpg
- result.jpg
