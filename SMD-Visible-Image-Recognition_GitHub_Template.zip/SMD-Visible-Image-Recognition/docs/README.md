# Documentation

This folder can store additional documentation and figures for the repository.
