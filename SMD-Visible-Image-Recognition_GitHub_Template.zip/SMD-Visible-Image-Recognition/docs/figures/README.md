# Figures

Place documentation figures here, such as model architecture diagrams.
