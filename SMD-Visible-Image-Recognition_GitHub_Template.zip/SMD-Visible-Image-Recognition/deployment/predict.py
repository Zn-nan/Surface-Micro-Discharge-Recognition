"""Inference example."""
