"""Training entry point."""
